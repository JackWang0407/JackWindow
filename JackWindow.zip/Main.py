import sys
from PyQt4 import QtGui, QtCore
import MainWindow,DownloadWindow






app = QtGui.QApplication(sys.argv)


win = MainWindow.Ui_MainWindow()

#win.move(0, 0)
win.show()

#win2 = DownloadWindow.Ui_MainWindow()
#win2.move(882, 0)
#win2.show()

sys.exit(app.exec_())

