# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'DownloadWindow.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

import youtube_dl
from PyQt4 import QtCore, QtGui
from bs4 import BeautifulSoup
import requests
import urllib

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)


def GetOpenloadVideo(path,filename):
    ydl = youtube_dl.YoutubeDL({'outtmpl': filename})
    with ydl:
        youtube_dlresult = ydl.extract_info(
            path,
            download=True  # !!We just want to extract the info
        )
    if 'entries' in youtube_dlresult:
        # Can be a playlist or a list of videos
        video = youtube_dlresult['entries'][0]
    else:
        # Just a video
        video = youtube_dlresult
    return video

def GetOpenloadVideoDownloadInfo(VedioNumber):
    Result = {
        "result": "PASS",
        "url": "",
        "filename": "",
    }
    keyword = VedioNumber
    # print keyword
    res = requests.get('http://sddpoav.com/?s=' + keyword)
    if res.status_code == requests.codes.ok:
        html = res.content
        soup = BeautifulSoup(html, 'html.parser')
        data = soup.find('div', attrs={'class': 'video'})
        if data is not None:
            if data.find('a') is not None:
                href = data.find('a').get('href')
            else:
                print "Cannot Find this AV Number - - http://sddpoav.com/"
                Result['result'] = "FAIL"
                return Result
        else:
            print "Cannot Find this AV Number - - http://sddpoav.com/"
            Result['result'] = "FAIL"
            return Result
        res = requests.get(href)
        if res.status_code == requests.codes.ok:
            html = res.content
            soup = BeautifulSoup(html, 'html.parser')
            video_path = soup.find('div', attrs={'class': 'video_code'}).find('iframe').get('src')
            #print video_path
            ydl = youtube_dl.YoutubeDL()
            with ydl:
                youtube_dlresult = ydl.extract_info(
                    video_path,
                    download=False  # !!We just want to extract the info
                )
            if 'entries' in youtube_dlresult:
                # Can be a playlist or a list of videos
                video = youtube_dlresult['entries'][0]
            else:
                # Just a video
                video = youtube_dlresult
            # print(video)
            Result['url'] = video['url']
            Result['filename'] = video['title']
    else:
        #print str(res.status_code)
        Result['result'] = "FAIL"
    return Result

def Get7MMVedioInfo(VedioNumber):
    Result = {
        "result": "PASS",
        "title": "",
        "number": "",
        "date": "",
        "avers": "",
        "video_long": "",
        "maker": "",
        "seller": "",
        "company": "",
        "img": "",
    }
    #print Result
    res = requests.post('https://7mm.tv/zh/searchform_search/all/index.html',
                        data={'search_keyword': unicode(VedioNumber), 'search_type': 'censored',
                        'op': 'search'})
    if res.status_code == requests.codes.ok:
        html = res.content
        soup = BeautifulSoup(html, 'html.parser')
        topic_area = soup.find('div', attrs={'class': 'topic_area'})
        topic_box = topic_area.find('div', attrs={'class': 'topic_box'})
        if topic_area is not None:
            if topic_box is not None:
                #print topic_box.find('a').get('href')
                None
            else:
                print "Cannot Find this AV Number - - https://7mm.tv"
                Result['result'] = "FAIL"
                return Result
        else:
            print "Cannot Find this AV Number - - https://7mm.tv"
            Result['result'] = "FAIL"
            return Result
        res = requests.get(topic_box.find('a').get('href'))
        if res.status_code == requests.codes.ok:
            html = res.content
            soup = BeautifulSoup(html, 'html.parser')
            contents_title = soup.find('div', attrs={'id': 'contents_title'})
            contents_title = contents_title.find('b').text
            #print contents_title
            #print '----------------'
            for mvinfo_dmm_A in soup.find_all('div', attrs={'class': 'mvinfo_dmm_A'}):
                if mvinfo_dmm_A.find('b').text == u"番號：":
                    #print mvinfo_dmm_A.text.lstrip(u"番號：")

                    Result["number"] = mvinfo_dmm_A.text.lstrip(u"番號：")

                    number = mvinfo_dmm_A.text.lstrip(u"番號：")
                    rm_string = "["+mvinfo_dmm_A.text.lstrip(u"番號：")+"]"
                    contents_title = contents_title.replace(rm_string, "")

                   # print contents_title
                if mvinfo_dmm_A.find('b').text == u"發行日期：":
                    #print mvinfo_dmm_A.text.lstrip(u"發行日期：")
                    date = mvinfo_dmm_A.text.lstrip(u"發行日期：")

                    Result["date"] = mvinfo_dmm_A.text.lstrip(u"發行日期：")

                if mvinfo_dmm_A.find('b').text == u"影片時長：":
                    #print mvinfo_dmm_A.text.lstrip(u"影片時長：")

                    Result["video_long"] = mvinfo_dmm_A.text.lstrip(u"影片時長：")
                    Result["video_long"] = Result["video_long"].split(u"（")[0]
                    #Result["video_long"] = mvinfo_dmm_A.text.lstrip(u"影片時長：")

                if mvinfo_dmm_A.find('b').text == u"導演：":
                    #print mvinfo_dmm_A.text.lstrip(u"導演：")
                    Result["maker"] = mvinfo_dmm_A.text.lstrip(u"導演：")
                if mvinfo_dmm_A.find('b').text == u"製作商：":
                    #print mvinfo_dmm_A.text.lstrip(u"製作商：")
                    Result["seller"] = mvinfo_dmm_A.text.lstrip(u"製作商：")
                if mvinfo_dmm_A.find('b').text == u"發行商：":
                    #print mvinfo_dmm_A.text.lstrip(u"發行商：")
                    Result["company"] = mvinfo_dmm_A.text.lstrip(u"發行商：")
            mvinfo_introduction = soup.find('div', attrs={'class': 'mvinfo_introduction'}).text
            avers=""
            for av_performer_name_box in soup.find_all('div', attrs={'class': 'av_performer_name_box'}):
                contents_title = contents_title.replace(av_performer_name_box.text, "")
                avers += av_performer_name_box.text+","
            #print avers.strip(",")
            Result["avers"] = avers.strip(",")
            contents_title = contents_title.lstrip(" ")
            contents_title = contents_title.lstrip(u" ")
            Result["title"] = contents_title
            img = soup.find('img').get('src')
            #print "Download from ",img,".."
            urllib.urlretrieve(img, 'tmp.jpg')
            Result["img"] = img
            #print "JackS: ", Result
            return Result
